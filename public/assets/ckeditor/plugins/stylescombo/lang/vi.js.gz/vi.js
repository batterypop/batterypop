/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/

CKEDITOR.plugins.setLang( 'stylescombo', 'vi', {
	label: 'Kiểu',
	panelTitle: 'Phong cách định dạng',
	panelTitle1: 'Kiểu khối',
	panelTitle2: 'Kiểu trực tiếp',
	panelTitle3: 'Kiểu đối tượng'
});
