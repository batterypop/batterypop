/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/

CKEDITOR.plugins.setLang( 'stylescombo', 'el', {
	label: 'Μορφές',
	panelTitle: 'Στυλ Μορφοποίησης',
	panelTitle1: 'Στυλ Κομματιών',
	panelTitle2: 'Στυλ Εν Σειρά',
	panelTitle3: 'Στυλ Αντικειμένων'
});
