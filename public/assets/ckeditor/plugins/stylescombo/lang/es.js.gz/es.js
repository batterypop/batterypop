/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/

CKEDITOR.plugins.setLang( 'stylescombo', 'es', {
	label: 'Estilo',
	panelTitle: 'Estilos para formatear',
	panelTitle1: 'Estilos de párrafo',
	panelTitle2: 'Estilos de carácter',
	panelTitle3: 'Estilos de objeto'
});
