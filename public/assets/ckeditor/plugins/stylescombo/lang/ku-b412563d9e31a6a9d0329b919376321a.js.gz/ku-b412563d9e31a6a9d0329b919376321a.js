/*
Copyright (c) 2003-2013, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/

CKEDITOR.plugins.setLang( 'stylescombo', 'ku', {
	label: 'شێواز',
	panelTitle: 'شێوازی ڕازاندنهوه',
	panelTitle1: 'شێوازی خشت',
	panelTitle2: 'شێوازی ناوهێڵ',
	panelTitle3: 'شێوازی بهرکار'
});
